import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent }  from './app.component';
import { MobileComponent }  from './app.mobilecomponent';

import { SortPipeFilter } from "./sortFilter";


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,MobileComponent,SortPipeFilter],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
