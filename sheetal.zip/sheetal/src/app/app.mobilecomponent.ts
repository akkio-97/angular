import { Component } from "@angular/core";
import { Mobile } from "./mobile";
import { MobileService } from "./app.mobile.service";

@Component( {
    selector: 'my-component',
    templateUrl: `./app.mobilecomponent.html`,
    providers: [MobileService]
} )
export class MobileComponent{
    col:any;
    mobileDetails: Mobile[] = [];
constructor( private mobileService: MobileService ) {

}
ngOnInit(): void {
    this.mobileService.getAllMobile().subscribe(( mobileData ) => this.mobileDetails = mobileData );
}
delete(mobile:Mobile){
    this.mobileService.onDelete(mobile,this.mobileDetails);
}
sort(property:any){
    this.col=property;
}
}