import { Component } from "@angular/core";

@Component({
    selector:'my-app',
        template:`{{name}}<my-component></my-component>`
})
export class AppComponent{
    name = "List of Mobiles";
}