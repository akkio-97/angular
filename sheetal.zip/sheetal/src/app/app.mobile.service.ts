import { Injectable } from "@angular/core";
import { Mobile } from "./Mobile";
import { Observable } from "rxjs/Observable";
import { Http,Response } from "@angular/http";
import "rxjs/add/operator/map"

@Injectable()
export class MobileService{
    delIndex:number;

    constructor(private http:Http){
        
    }
    getAllMobile():Observable<Mobile[]>{
       
        return this.http.get("app/mobile.json").
        map((response:Response)=><Mobile[]>response.json());
        
    }
    onDelete(mobile:Mobile,mobileDetails:Mobile[]){
        this.delIndex=mobileDetails.indexOf(mobile, 0)
        mobileDetails.splice( this.delIndex, 1 );
      
    }
}