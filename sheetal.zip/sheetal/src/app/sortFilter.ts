import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:"sortPipe",
    pure:false
})
export class SortPipeFilter implements PipeTransform{
    transform(mob: Array<any>, args?: any) {
        return mob.sort(function(a, b){
           
            if(a[args.property] < b[args.property]){
                return -1 ;
            }
            else if( a[args.property] > b[args.property]){
                return 1 ;
            }
            else{
                return 0;
            }
        });
    }
    
}