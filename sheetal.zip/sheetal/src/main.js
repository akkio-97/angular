"use strict";
//responsible for loading the Angular 2 application in the desktop browser.
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var app_module1_1 = require("./app/app.module1");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module1_1.AppModule);
