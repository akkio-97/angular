//responsible for loading the Angular 2 application in the desktop browser.
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module1';

platformBrowserDynamic().bootstrapModule(AppModule);
