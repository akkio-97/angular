import {Component, OnInit} from '@angular/core';
import {IBook} from './app.book';
import {Book} from './app.bookImpl';
import {BookService} from './app.book.service';
import { NgForm } from "@angular/Forms/forms";

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.bookcomponent.html',
    providers: [BookService]
})

export class BookComponent implements OnInit {
    books: IBook[];

    newId: number;
    newTitle: string;
    newAuthor: string;
    newYear: number;
    newPrice: number;
    option: number;
    
    
    addBook(id:number, title:string, author:string, year:number, price:number): void {
        this.option=0;
        this.books.push(new Book(id, title, author, year,price));
        console.log("Add Book method");
    }
    
    showBook(id: number):void {
        for(var i = 0; i < this.books.length; i++) {
            if(this.books[i].id == id) {
                console.log(this.books[i]);
                this.newId = this.books[i].id;
                this.newTitle = this.books[i].title;
                this.newAuthor = this.books[i].author;
                this.newYear = this.books[i].year;
                this.newPrice = this.books[i].price;
                return;
            }
        }
    }
    
    updateBook(newId:number,newTitle:string,newAuthor:string,newYear:number, newPrice:number): void{
        this.option=2;
        for(var i = 0; i < this.books.length; i++) {
            if(this.books[i].id == newId) {
                //this.books[i] = new Book(newId, newTitle, newAuthor, newYear);
                //this.books[i].id=newId; //Not needed bcoz Readonly
                this.books[i].title = newTitle;
                this.books[i].author = newAuthor;
                this.books[i].year = newYear;
                this.books[i].price = newPrice;
                console.log("Update Book method");
                return;
            }
        }
    }
    
    
    
    deleteBook(id: number):void {
        this.option = 1;
         for(var i = 0; i < this.books.length; i++) {
             if(this.books[i].id == id) {
                 console.log(this.books[i]);
                 this.books.splice(i, 1);
                 return;
             }
             
         }
    }
    

    search: string = '';
    constructor(private bookService: BookService) {
        
    }
    
    ngOnInit(): void {
        console.log("ng-init called...");
        this.bookService.getAllBooks().subscribe((bookData) => this.books = bookData);
    }
    
   /*ngOnChanges(): void {
        console.log("ng-changes called...");
    }*/
    
    sortById() {
        console.log("Sorting by Id...");
        this.books.sort(function(book1, book2) {
            return (book1.id - book2.id);
        });
    }

    sortByTitle() {
        console.log("Sorting by title...");
        this.books.sort(function(book1, book2) {
            return (book1.title.localeCompare(book2.title));
        });
    }

    sortByYear() {
        console.log("Sorting by Year...");
        this.books.sort(function(book1, book2) {
            return (book1.year - book2.year);
        });
    }

    sortByAuthor() {
        console.log("Sorting by Author...");
        this.books.sort(function(book1, book2) {
            return (book1.author.localeCompare(book2.author));
        });
    }
    
    sortByPrice() {
        console.log("Sorting by Price...");
        this.books.sort(function(book1, book2) {
            return (book1.price - book2.price);
        });
    }

    index: number = 0;

    changeIndexToOne(): void {
        this.index = 1;
        console.log("index changed to: " + this.index);
    }
    changeIndexToTwo(): void {
        this.index = 2;
        console.log("index changed to: " + this.index);
    }
    changeIndexToThree(): void {
        this.index = 3;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFour(): void {
        this.index = 4;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFive(): void {
        this.index = 5;
        console.log("index changed to: " + this.index);
    }
}
 