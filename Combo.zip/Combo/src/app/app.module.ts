import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { BookComponent }  from './app.bookcomponent';
import { HttpModule } from '@angular/http';
import { SearchPipe }  from './app.filter';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule ],
  declarations: [ AppComponent ,BookComponent, SearchPipe],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
