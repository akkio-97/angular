"use strict";
var Book = (function () {
    function Book(id, title, author, year, price) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.price = price;
    }
    return Book;
}());
exports.Book = Book;
