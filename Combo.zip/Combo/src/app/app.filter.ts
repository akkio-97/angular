import {  Pipe, PipeTransform }      from '@angular/core';
import { IBook } from "./app.book";

@Pipe({
  name: 'searchPipe',
  pure: false
})

export class SearchPipe implements PipeTransform {
    transform(books:any, search:any, index:number): any {
        if(search == null || search == undefined) return books;
           
        return books.filter(function(book:any){
        console.log(book);
        let val: any;
        switch(index) {
            case 1: val = book.id.toString().includes(search); break;
            case 2: val = book.title.toLowerCase().includes(search.toLowerCase()); break;
            case 3: val = book.author.toLowerCase().includes(search.toLowerCase()); break;
            case 4: val = book.year.toString().includes(search); break;
            case 5: val = book.price.toString().includes(search); break;
            default: console.log("Something is wrong");
        }
        return val; 
      })
   }
}