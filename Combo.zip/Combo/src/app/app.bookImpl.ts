import { IBook } from "./app.book";

export class Book implements IBook{
    id: number;
    title: string;
    author: string;
    year: number;
    price: number;
    
    constructor (id: number, title: string, author: string, year: number, price: number) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.price = price;
    }
}