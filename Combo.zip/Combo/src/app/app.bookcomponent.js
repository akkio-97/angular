"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var app_bookImpl_1 = require("./app.bookImpl");
var app_book_service_1 = require("./app.book.service");
var BookComponent = (function () {
    function BookComponent(bookService) {
        this.bookService = bookService;
        this.search = '';
        this.index = 0;
    }
    BookComponent.prototype.addBook = function (id, title, author, year, price) {
        this.option = 0;
        this.books.push(new app_bookImpl_1.Book(id, title, author, year, price));
        console.log("Add Book method");
    };
    BookComponent.prototype.showBook = function (id) {
        for (var i = 0; i < this.books.length; i++) {
            if (this.books[i].id == id) {
                console.log(this.books[i]);
                this.newId = this.books[i].id;
                this.newTitle = this.books[i].title;
                this.newAuthor = this.books[i].author;
                this.newYear = this.books[i].year;
                this.newPrice = this.books[i].price;
                return;
            }
        }
    };
    BookComponent.prototype.updateBook = function (newId, newTitle, newAuthor, newYear, newPrice) {
        this.option = 2;
        for (var i = 0; i < this.books.length; i++) {
            if (this.books[i].id == newId) {
                //this.books[i] = new Book(newId, newTitle, newAuthor, newYear);
                //this.books[i].id=newId; //Not needed bcoz Readonly
                this.books[i].title = newTitle;
                this.books[i].author = newAuthor;
                this.books[i].year = newYear;
                this.books[i].price = newPrice;
                console.log("Update Book method");
                return;
            }
        }
    };
    BookComponent.prototype.deleteBook = function (id) {
        this.option = 1;
        for (var i = 0; i < this.books.length; i++) {
            if (this.books[i].id == id) {
                console.log(this.books[i]);
                this.books.splice(i, 1);
                return;
            }
        }
    };
    BookComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("ng-init called...");
        this.bookService.getAllBooks().subscribe(function (bookData) { return _this.books = bookData; });
    };
    /*ngOnChanges(): void {
         console.log("ng-changes called...");
     }*/
    BookComponent.prototype.sortById = function () {
        console.log("Sorting by Id...");
        this.books.sort(function (book1, book2) {
            return (book1.id - book2.id);
        });
    };
    BookComponent.prototype.sortByTitle = function () {
        console.log("Sorting by title...");
        this.books.sort(function (book1, book2) {
            return (book1.title.localeCompare(book2.title));
        });
    };
    BookComponent.prototype.sortByYear = function () {
        console.log("Sorting by Year...");
        this.books.sort(function (book1, book2) {
            return (book1.year - book2.year);
        });
    };
    BookComponent.prototype.sortByAuthor = function () {
        console.log("Sorting by Author...");
        this.books.sort(function (book1, book2) {
            return (book1.author.localeCompare(book2.author));
        });
    };
    BookComponent.prototype.sortByPrice = function () {
        console.log("Sorting by Price...");
        this.books.sort(function (book1, book2) {
            return (book1.price - book2.price);
        });
    };
    BookComponent.prototype.changeIndexToOne = function () {
        this.index = 1;
        console.log("index changed to: " + this.index);
    };
    BookComponent.prototype.changeIndexToTwo = function () {
        this.index = 2;
        console.log("index changed to: " + this.index);
    };
    BookComponent.prototype.changeIndexToThree = function () {
        this.index = 3;
        console.log("index changed to: " + this.index);
    };
    BookComponent.prototype.changeIndexToFour = function () {
        this.index = 4;
        console.log("index changed to: " + this.index);
    };
    BookComponent.prototype.changeIndexToFive = function () {
        this.index = 5;
        console.log("index changed to: " + this.index);
    };
    return BookComponent;
}());
BookComponent = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.bookcomponent.html',
        providers: [app_book_service_1.BookService]
    }),
    __metadata("design:paramtypes", [app_book_service_1.BookService])
], BookComponent);
exports.BookComponent = BookComponent;
