import { Component } from '@angular/core';

@Component({
  
  templateUrl: './app.add.html'
})
export class HomeComponent { }
